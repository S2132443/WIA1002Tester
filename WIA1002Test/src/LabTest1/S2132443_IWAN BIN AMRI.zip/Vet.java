package LabTest1;

import java.util.ArrayList;

public class Vet {

    String name;
    String qualification;
    
    

    public Vet(String name, String qualification) {
        this.name = name;
        this.qualification = qualification;
    }

    public String getName() {
        return name;
    }

    public String getQualification() {
        return qualification;
    }

    public void giveTreatment(ArrayList<P,M,D>){
    
    }

}
