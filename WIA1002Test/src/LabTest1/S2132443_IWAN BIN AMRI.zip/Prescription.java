package LabTest1;



public class Prescription<P extends Pet,M,D> {

    P pet;
    M medication;
    D dosage;

    public Prescription (double price) {
        
    }

 
}
